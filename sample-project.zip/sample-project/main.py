def sayHello(x):
	print("Hello, " + x)

sayHello("user")
sayHello("world")
